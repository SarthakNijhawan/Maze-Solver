see http://ee368.stanford.edu/Android

