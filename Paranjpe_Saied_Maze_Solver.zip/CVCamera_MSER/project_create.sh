android update project --name CVCamera_MSER --path .
cp project.properties default.properties
