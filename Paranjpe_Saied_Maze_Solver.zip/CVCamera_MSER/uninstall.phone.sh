#!/bin/bash
echo uninstalling CVCamera from phone
adb uninstall com.theveganrobot.cvcamera
